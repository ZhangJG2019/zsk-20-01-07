<template>
  <div class="drug-news">
    <div class="box-top-title gene-box">
      <p class="w">
        <i class="icon-box"></i>奥美拉唑
      </p>
    </div>
    <div class="w clearfix d-flex">
      <div class="left-box">
        <ul class="tips-list">
          <li class="list-box" :class="{'cur':tabsCur=='0'}" @click="tabsliClick('0')">
            <i class="el-icon-arrow-right icon-right"></i>总结
          </li>
          <li class="list-box" :class="{'cur':tabsCur=='1'}" @click="tabsliClick('1')">
            <i class="el-icon-arrow-right icon-right"></i>药物商品名
          </li>
          <li class="list-box" :class="{'cur':tabsCur=='2'}" @click="tabsliClick('2')">
            <i class="el-icon-arrow-right icon-right"></i>药物说明书
          </li>
          <li class="list-box" :class="{'cur':tabsCur=='3'}" @click="tabsliClick('3')">
            <i class="el-icon-arrow-right icon-right"></i>药物医保目录
          </li>
          <li class="list-box" :class="{'cur':tabsCur=='4'}" @click="tabsliClick('4')">
            <i class="el-icon-arrow-right icon-right"></i>药物相互作用
          </li>
        </ul>
        <span class="tips-border" :style="{top:(tabIndex*40+35)+'px'}"></span>
      </div>
      <div class="right-content-box detail-box-content">
        <div v-if="tabsCur=='0'">
          <h4 class="section-box">概述</h4>
          <div class="text-box">
            奥美拉唑是质子泵抑制药，为白色或类白色结晶性粉末；无臭；遇光易变色。对基础胃酸分泌和各种刺激因素引起的胃酸分泌均有很强的抑制作用。主要用于治疗十二指肠溃疡和卓-艾综合征，
            也可用于胃溃疡和反流性食管炎。静脉或口服给药。中毒时主要影响肝脏、肾脏、神经系统、呼吸系统、心血管系统及血液系统。
          </div>
          <div class="detail-box-top">
            <p>作者:</p>
            <p>来源:</p>
            <p>年份:</p>
            <p>卷期:</p>
            <p>文献类型:</p>
          </div>
        </div>

        <div v-if="tabsCur=='1'">
          <h4 class="section-box">药物商品名</h4>
          <div class="drug-news-box">
            <ul class="section-box-word">
              <li class="word-list">
                <i class="word-icon"></i>
                <div class="boxes">
                  <p style="font-size:16px; font-weight:600; color:#222">奥美拉唑</p>
                  <p style=" margin-top:10px;"><span class="tips">规格：20mg</span><span class="tips">批准文号：国药准字H4402397</span></p>
                  <p style=" margin-top:5px;"><span class="tips">品牌：佊司克</span><span class="tips">国家/厂家：广州彼迪药业有限公司</span></p>
                </div>
              </li>
              <li class="word-list">
                <i class="word-icon"></i>
                <div class="boxes">
                  <p style="font-size:16px; font-weight:600; color:#222">奥美拉唑</p>
                  <p style=" margin-top:10px;"><span class="tips">规格：20mg</span><span class="tips">批准文号：国药准字H4402397</span></p>
                  <p style=" margin-top:5px;"><span class="tips">品牌：佊司克</span><span class="tips">国家/厂家：广州彼迪药业有限公司</span></p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div v-if="tabsCur=='2'">
          <h4 class="section-box">药物说明书</h4>
          <div class="drug-news-box">
            <ul class="section-box-word">
              <li class="word-list">
                <i class="word-icon"></i>
                <div class="boxes">
                  <p style="font-size:16px; font-weight:600; color:#222">奥美拉唑肠溶胶囊<span style="font-size:12px; padding-left:12px;">（英文名：(R)-omeprazole）</span></p>
                  <p style=" margin-top:10px;"><span class="tips">说明书来源：悦康药业集团有限公司 </span><span class="tips">规格：20mg </span><span class="tips">批准文号：国药准字H20059988 </span></p>
                  <p style=" margin-top:5px;"><span class="tips">适应症：适用于胃溃疡、十二指肠溃疡、应激性溃疡、反流性食管炎和卓．艾综合征(胃泌素瘤)。</span></p>
                  <p style=" margin-top:15px;"><span class="undline-text">查看全文</span><em class="line-black">|</em><span class="undline-text">下载</span><em class="line-black">|</em><span class="undline-text">包装图片</span></p>
                </div>
              </li>

            </ul>
          </div>
        </div>

        <div v-if="tabsCur=='3'"></div>

        <div v-if="tabsCur=='4'"></div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from "vue";
import { tabs } from "@/utils/style_config.js";

export default {
  name: "path_ways",
  // 生命周期函数
  data() {
    return {
      componentVue: "",
      tabs: tabs,
      tabsCur: "0",
      queryObj: "",
      tabIndex: "0"
    };
  },
  created() {
    this.queryObj =
      Object.keys(this.$route.query).length > 0 ? this.$route.query : {};
  },
  components: {},
  methods: {
    tabsliClick(index) {
      if (this.tabsCur == index) return;
      this.tabsCur = index;
      this.tabIndex = index;
    }
  }
};
</script>

<style lang="scss" scoped>
.drug-news {
  background: #fff;
  .box-top-title {
    padding: 25px 0;
    line-height: 65px;
    font-size: 32px;
    color: #3c8cbf;
    .icon-box {
      margin-right: 20px;
    }
    &.gene-box {
      background: #eee;
      .icon-box {
        background: url("../../../../public/images/home-drug.png") no-repeat;
        background-size: contain;
        width: 64px;
        height: 63px;
        display: inline-block;
        vertical-align: top;
      }
    }
  }
  .d-flex {
    display: flex;
  }
  .left-box {
    width: 265px;
    position: relative;
    z-index: 2;
    border-right: 1px solid #eee;
    min-height: 500px;
    .tips-list {
      padding-top: 35px;
      .list-box {
        position: relative;
        height: 40px;
        line-height: 40px;
        font-size: 15px;
        color: #333;
        padding-left: 30px;
        cursor: pointer;
        &:hover {
          color: #3c8cbf;
        }
        .icon-right {
          position: absolute;
          display: none;
          left: 0;
          font-size: 22px;
          top: 9px;
        }
        &.cur {
          color: #3c8cbf;
          .icon-right {
            display: block;
          }
        }
      }
    }
    .tips-border {
      position: absolute;
      right: -1px;
      width: 2px;
      height: 40px;
      background: #3c8cbf;
      transition: top 0.3s;
    }
  }
  .right-content-box {
    flex: 1;
    padding: 25px 0 60px 40px;
    position: relative;
    z-index: 1;
    &.detail-box-content {
      .flex-center {
        display: flex;
        align-items: center;
        &.flex-between {
          justify-content: space-between;
        }
        &.flex-around {
          justify-content: space-around;
        }
      }
      .detail-box-top {
        padding-top: 20px;
        padding-bottom: 10px;
        .page-title-name {
          font-size: 26px;
          color: #333;
          padding: 15px 0;
          line-height: 38px;
        }
        p {
          line-height: 30px;
          color: #333;
        }
      }
      .section-box {
        font-size: 16px;
        color: #444;
        padding: 15px 0 0;
        line-height: 30px;
        font-weight: 600;
      }

    }
    .text-box {
      line-height: 30px;
      font-size: 14px;
      color: #666;
    }
    .drug-news-box {
      margin-top: 15px;
      .section-box-word {
        .word-list {
          position: relative;
          line-height: 20px;
          padding: 15px 0 5px 80px;
          font-size: 14px;
          color: #333;
          .word-icon {
            position: absolute;
            left: 0;
            top: 19px;
            font-size: 35px;
            color: #3c8cbf;
            background: url("../../../../public/images/home-drug.png")
              no-repeat;
            background-size: contain;
            width: 55px;
            height: 55px;
          }
          .boxes {
            border-bottom:1px solid #ddd;
            padding-bottom:15px;
            color: #888;
            .tips {
              padding-right: 20px;
              &:last-child {
                padding-right: 0;
              }
            }
            .undline-text {
              text-decoration:underline;
              cursor: pointer;
              font-size: 12px;
            }
            .line-black {
              padding: 0 20px;
            }
          }
        }
      }
    }
  }
}
</style>
<style lang="scss">
.path-ways {
  .table {
    margin-top: 10px;
    .el-table {
      border: 1px solid #ccc;
    }
    .el-table th {
      background: #ebf3f8;
      border: none;
      padding: 4px 0;
      font-weight: normal;
      color: #333;
    }
    .el-table td {
      border-bottom: none;
      color: #333;
      font-size: 14px;
      border-right: 1px solid #ccc;
      padding: 8px 0;
    }
  }
}
</style>
