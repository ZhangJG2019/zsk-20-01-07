<template>
  <div class="detail-content">
    <div class="clearfix breadcrumb-nav">
      <div class="w">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>搜索结果</el-breadcrumb-item>
          <el-breadcrumb-item>临床注释</el-breadcrumb-item>
          <el-breadcrumb-item>临床注释(位点)</el-breadcrumb-item>
          <el-breadcrumb-item>内容详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
    </div>
    <div style="border-top:1px solid #eee;">
      <div class="w clearfix d-flex">
        <div class="left-box">
          <b style="font-size:16px; color:#333;">题目</b>
          <ul class="tips-list">
            <li
              class="list-box"
              :class="{'cur':item.id==tabsCur}"
              v-for="(item, index) in tabs"
              @click="tabsliClick(item,index)"
              :key="'tabs'+index"
            >
              <i class="icon-right">{{index+1}}</i>
              <p class="ellipsis" style="font-size:15px;">{{item.name}}</p>
            </li>
          </ul>
          <div class="pagination clearfix">
            <el-pagination
              small
              :page-size="pageSize"
              @current-change="pageChange"
              layout="prev, pager, next"
              :total="100"
            ></el-pagination>
          </div>
        </div>
        <div class="right-content-box">
          <p class="detail-tab">
            <el-button class="tabcur">注释查看</el-button>
          </p>
          <div class="china-box">
            <div class="detail-box-top">
              <h3 class="page-title-name">奥美拉唑-CYP2D6</h3>
            </div>
            <div class="detail-box-top">
              <ul class="clearfix">
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">项目英文名称：</label>Omeprazole-CYP2D6
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">项目编码：</label>N212131345
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">证据等级：</label>N212131345
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">用药类型：</label>预测疗效
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">药物：</label>奥美拉唑
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">基因：</label>CYP2C19
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">单倍型：</label>Btr2.3a
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">位点：</label>HvBtr2
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">位点RSID：</label>HvBtr2
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">种族：</label>汉族
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">种族详情：</label>
                </li>
                <li style="width:50%; line-height:35px; float:left; color:#333;">
                  <label style="display:inline-block; width:110px; font-weight:600">疾病：</label>
                </li>
              </ul>
            </div>
            <div class="detail-box-content notes-box">
              <div class="table" style="margin-top:20px;">
                <el-table border style="width: 100%">
                  <el-table-column prop="genes" width="180" label="基因型" align="center"></el-table-column>
                  <el-table-column prop="genes" label="临床建议" align="left"></el-table-column>
                </el-table>
              </div>
              <h4 class="section-box">证据</h4>
              <div class="table">
                <el-tabs v-model="activeName2" type="card">
                  <el-tab-pane label="国内文献" name="first">
                    <el-table border style="width: 100%">
                      <el-table-column prop="genes" width="180" label="申请号" align="center"></el-table-column>
                      <el-table-column prop="genes" label="题目" align="left"></el-table-column>
                      <el-table-column prop="porName" width="180" align="center" label="期刊"></el-table-column>
                      <el-table-column prop="porName" width="180" align="center" label="年份"></el-table-column>
                    </el-table>
                  </el-tab-pane>
                  <el-tab-pane label="国外文献" name="second">
                    <el-table border style="width: 100%">
                      <el-table-column prop="genes" width="180" label="PMID" align="center"></el-table-column>
                      <el-table-column prop="genes" label="题目" align="left"></el-table-column>
                      <el-table-column prop="porName" width="180" align="center" label="期刊"></el-table-column>
                      <el-table-column prop="porName" width="180" align="center" label="年份"></el-table-column>
                    </el-table>
                  </el-tab-pane>
                </el-tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from "vue";

export default {
  name: "clinicalNotesWeidDetail",
  // 生命周期函数
  data() {
    return {
      tabsCur: "12",
      pageSize: 10,
      pageNum: 1,
      tabs: [
        {
          name: "奥拉美唑—CYTDER207",
          id: "12"
        },
        {
          name: "奥拉美唑—CYTDER207",
          id: "123"
        },
        {
          name: "奥拉美唑—CYTDER207",
          id: "124"
        },
        {
          name: "奥拉美唑—CYTDER207",
          id: "125"
        },
        {
          name: "奥拉美唑—CYTDER207",
          id: "162"
        }
      ],
      activeName2: "first"
    };
  },
  created() {},
  methods: {
    pageChange(v) {
      if (v == this.pageNum) return;
      this.pageNum = v;
      this.getListDatas();
      document.body.scrollTop = document.documentElement.scrollTop = 0;
    },
    tabsliClick(obj, index) {
      if (this.tabsCur == obj.id) return;
      this.tabsCur = obj.id;
    }
  }
};
</script>

<style lang="scss" scoped>
.detail-content {
  background: #fff;
  .breadcrumb-nav {
    border-top: 1px solid #eee;
    padding: 15px 0 15px;
    line-height: 35px;
  }
  .d-flex {
    display: flex;
  }
  .left-box {
    width: 265px;
    position: relative;
    z-index: 2;
    border-right: 1px solid #eee;
    min-height: 500px;
    padding-top: 25px;
    .tips-list {
      padding-top: 15px;
      .list-box {
        position: relative;
        line-height: 25px;
        font-size: 15px;
        color: #333;
        padding-left: 20px;
        padding-bottom: 15px;
        cursor: pointer;
        &:hover {
          color: #3c8cbf;
        }
        .icon-right {
          position: absolute;
          left: 0;
          font-size: 14px;
          top: 0;
          color: #566;
          line-height: 25px;
        }
        &.cur {
          p {
            color: #3c8cbf !important;
          }
        }
      }
    }
    .tips-border {
      position: absolute;
      right: -1px;
      width: 2px;
      height: 40px;
      background: #3c8cbf;
      transition: top 0.3s;
    }
    .pagination {
      padding-top: 10px;
    }
  }
  .right-content-box {
    flex: 1;
    padding: 25px 0 60px 40px;
    position: relative;
    z-index: 1;
    .detail-box-top {
      padding-top: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
      .page-title-name {
        font-size: 26px;
        color: #333;
        padding: 15px 0;
        line-height: 38px;
      }
      p {
        line-height: 30px;
        color: #333;
      }
    }
    .detail-box-content {
      .section-box {
        font-size: 16px;
        color: #444;
        padding: 20px 0 10px;
        line-height: 30px;
        font-weight: 600;
      }
      .section-box-text {
        li {
          color: #333;
          font-size: 14px;
          line-height: 30px;
          &::before {
            content: "";
            display: inline-block;
            width: 5px;
            height: 5px;
            background: #ccc;
            border-radius: 50%;
            vertical-align: middle;
            margin-right: 8px;
          }
        }
      }
      &.notes-box {
        .section-box-word {
          .word-list {
            position: relative;
            line-height: 20px;
            padding: 15px 0 12px 48px;
            font-size: 14px;
            color: #333;
            .word-icon {
              position: absolute;
              left: 0;
              top: 19px;
              font-size: 35px;
              color: #3c8cbf;
              background: url("../../../../public/images/linchuangzhushi.png")
                no-repeat;
              background-size: contain;
              width: 30px;
              height: 30px;
            }
            .qkuang-list {
              margin-top: 8px;
              border: 1px solid #eee;
              padding: 8px;
              dd {
                float: left;
                padding: 0 10px;
                border-right: 1px solid #ededed;
                margin: 10px 0;
                color: #666;
                font-size: 14px;
              }
            }
          }
        }
      }
    }
    .text-box {
      line-height: 30px;
      font-size: 14px;
      color: #333;
    }
  }
}
</style>
<style lang="scss">
.detail-tab {
  .tabcur {
    padding: 9px 30px;
    background: #d7e8f2;
    border-color: #d7e8f2;
    color: #3c8cbf;
  }
  .tabdefault {
    padding: 9px 30px;
    background: #fff;
    border-color: #3c8cbf;
    color: #3c8cbf;
  }
}
.table {
  margin-top: 5px;
  .el-table {
    border: 1px solid #ccc;
  }
  .el-table th {
    background: #ebf3f8;
    padding: 4px 0;
    font-weight: normal;
    color: #333;
  }
  .el-table td {
    color: #333;
    font-size: 14px;
    border-right: 1px solid #ccc;
    padding: 8px 0;
  }
}
</style>
