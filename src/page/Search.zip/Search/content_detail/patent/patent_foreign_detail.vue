<template>
  <div class="detail-content">
    <div class="clearfix breadcrumb-nav">
      <div class="w">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>搜索结果</el-breadcrumb-item>
          <el-breadcrumb-item>全球专利</el-breadcrumb-item>
          <el-breadcrumb-item>内容详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
    </div>
    <div style="border-top:1px solid #eee;">
      <div class="w clearfix d-flex">
        <div class="left-box">
          <b style="font-size:16px; color:#333;">题目</b>
          <ul class="tips-list">
            <li
              class="list-box"
              :class="{'cur':item.id==tabsCur}"
              v-for="(item, index) in tabs"
              @click="tabsliClick(item,index)"
              :key="'tabs'+index"
            >
              <i class="icon-right">{{index+1}}</i>
              <p class="ellipsis" style="color:#888;font-size:15px;">{{item.name}}</p>
              <p class="ellipsis">{{item.label}}</p>
            </li>
          </ul>
          <div class="pagination clearfix">
            <el-pagination
              small
              :page-size="pageSize"
              @current-change="pageChange"
              layout="prev, pager, next"
              :total="100"
            ></el-pagination>
          </div>
        </div>
        <div class="right-content-box">
          <p class="detail-tab">
            <el-button class="tabcur">注释查看</el-button>
            <el-button class="tabdefault">原文查看</el-button>
          </p>
          <div class="china-box">
            <div class="detail-box-top">
              <h3 class="page-title-name">
                <strong>Vue.js是一套构建用户界面的渐进式框架</strong>
              </h3>
              <p class="left-title">
                <span class="title">专利标题:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">申请号:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">公开号:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">申请日:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">公开日:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">发明人:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">申请人:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">药物:</span>
                <span class="right-content">111111</span>
              </p>
              <p class="left-title">
                <span class="title">基因:</span>
                <span class="right-content">111111</span>
              </p>
            </div>
            <div class="detail-box-content">
              <h4 class="section-box">
                <strong>摘要</strong>
              </h4>
              <p
                class="text-box"
              >Vue.js是一套构建用户界面的渐进式框架。与其他重量级框架不同的是，Vue 采用自底向上增量开发的设计。Vue 的核心库只关注视图层，并且非常容易学习，非常容易与其它库或已有项目整合。另一方面，Vue 完全有能力驱动采用单文件组件和Vue生态系统支持的库开发的复杂单页应用。</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from "vue";

export default {
  name: "patentForeignDetail",
  // 生命周期函数
  data() {
    return {
      tabsCur: "12",
      pageSize: 10,
      pageNum: 1,
      tabs: [
        {
          name: "akflaj",
          label: "交房贷拉设计费拉设计费拉设计费打死了阿熟练度附近说了",
          id: "12"
        },
        {
          name: "akflaj",
          label: "交房贷拉设计费拉设计费拉设计费打死了阿熟练度附近说了",
          id: "123"
        },
        {
          name: "akflaj",
          label: "交房贷拉设计费拉设计费拉设计费打死了阿熟练度附近说了",
          id: "124"
        },
        {
          name: "akflaj",
          label: "交房贷拉设计费拉设计费拉设计费打死了阿熟练度附近说了",
          id: "125"
        },
        {
          name: "akflaj",
          label: "交房贷拉设计费拉设计费拉设计费打死了阿熟练度附近说了",
          id: "162"
        }
      ]
    };
  },
  created() {},
  methods: {
    pageChange(v) {
      if (v == this.pageNum) return;
      this.pageNum = v;
      this.getListDatas();
      document.body.scrollTop = document.documentElement.scrollTop = 0;
    },
    tabsliClick(obj, index) {
      if (this.tabsCur == obj.id) return;
      this.tabsCur = obj.id;
    }
  }
};
</script>

<style lang="scss" scoped>
.left-title {
  height: 40px;
  line-height: 40px;
}
.left-title .title {
  font-weight: 700;
  width: 8.75rem;
  display: inline-block;
}
.detail-content {
  background: #fff;
  .breadcrumb-nav {
    border-top: 1px solid #eee;
    padding: 15px 0 15px;
    line-height: 35px;
  }
  .d-flex {
    display: flex;
  }
  .left-box {
    width: 265px;
    position: relative;
    z-index: 2;
    border-right: 1px solid #eee;
    min-height: 500px;
    padding-top: 25px;
    .tips-list {
      padding-top: 15px;
      .list-box {
        position: relative;
        line-height: 25px;
        font-size: 13px;
        color: #333;
        padding-left: 20px;
        padding-bottom: 10px;
        cursor: pointer;
        &:hover {
          color: #3c8cbf;
        }
        .icon-right {
          position: absolute;
          left: 0;
          font-size: 14px;
          top: 0;
          color: #566;
          line-height: 50px;
        }
        &.cur {
          p {
            color: #3c8cbf !important;
          }
        }
      }
    }
    .tips-border {
      position: absolute;
      right: -1px;
      width: 2px;
      height: 40px;
      background: #3c8cbf;
      transition: top 0.3s;
    }
    .pagination {
      padding-top: 10px;
    }
  }
  .right-content-box {
    flex: 1;
    padding: 25px 0 60px 40px;
    position: relative;
    z-index: 1;
    .detail-box-top {
      padding-top: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
      .page-title-name {
        font-size: 26px;
        color: #333;
        padding: 15px 0;
        line-height: 38px;
      }
      p {
        line-height: 30px;
        color: #333;
      }
    }
    .detail-box-content {
      .section-box {
        font-size: 16px;
        color: #444;
        padding: 20px 0 10px;
        line-height: 30px;
        font-weight: 600;
      }
      .section-box-text {
        li {
          color: #333;
          font-size: 14px;
          line-height: 30px;
          &::before {
            content: "";
            display: inline-block;
            width: 5px;
            height: 5px;
            background: #ccc;
            border-radius: 50%;
            vertical-align: middle;
            margin-right: 8px;
          }
        }
      }
      .section-box-word {
        .word-list {
          position: relative;
          padding-left: 45px;
          line-height: 20px;
          padding-bottom: 12px;
          .word-icon {
            position: absolute;
            left: 0;
            top: 7px;
            font-size: 35px;
            color: #3c8cbf;
          }
        }
      }
    }
    .text-box {
      line-height: 30px;
      font-size: 14px;
      color: #333;
    }
  }
}
</style>
<style lang="scss">
.detail-tab {
  .tabcur {
    padding: 9px 30px;
    background: #d7e8f2;
    border-color: #d7e8f2;
    color: #3c8cbf;
  }
  .tabdefault {
    padding: 9px 30px;
    background: #fff;
    border-color: #3c8cbf;
    color: #3c8cbf;
  }
}
.table {
  margin-top: 5px;
  .el-table {
    border: 1px solid #ccc;
  }
  .el-table th {
    background: #ebf3f8;
    padding: 4px 0;
    font-weight: normal;
    color: #333;
  }
  .el-table td {
    color: #333;
    font-size: 14px;
    border-right: 1px solid #ccc;
    padding: 8px 0;
  }
}
</style>
