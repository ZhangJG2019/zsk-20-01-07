<template>
  <div class="hook-box">
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="参与通路" name="first">
        <h6 style="margin-top:10px; font-size:20px; color:#333;">概述</h6>
        <div class="text-box">
          Vue.js是一套构建用户界面的渐进式框架。与其他重量级框架不同的是，Vue 采用自底向上增量开发的设计。Vue 的核心库只关注视图层，并且非常容易学习，非常容易与其它库或已有项目整合。另一方面，Vue 完全有能力驱动采用单文件组件和Vue生态系统支持的库开发的复杂单页应用。
        </div>
        <div class="table">
          <el-table
            border
            style="width: 100%">
            <el-table-column
              prop="genes"
              label="通路"
              align="center">
            </el-table-column>
            <el-table-column
              prop="genes"
              label="药物"
              align="center">
            </el-table-column>
            <el-table-column
              prop="porName"
              align="center"
              label="基因">
            </el-table-column>
            <el-table-column
              prop="porName"
              align="center"
              label="疾病">
            </el-table-column>
          </el-table>
        </div>
      </el-tab-pane>

    </el-tabs>
  </div>
</template>
<script>
export default {
  name:"pathways_hook",
  data(){
    return {
        activeName: 'first'
      };
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    }
  }
}
</script>
<style lang="scss" scoped>
  .text-box {
    line-height: 30px;
    color: #888;
    margin-top: 15px;
    font-size: 13px;
  }

</style>
<style lang="scss">
  .hook-box {
    .el-tabs__nav-scroll {
      height: 45px;
      .el-tabs__nav {
        height: 45px;
        .el-tabs__active-bar {
          background: #398dbc;
        }
        .el-tabs__item {
          font-size: 24px;
          color: #888;
          &.is-active {
            color: #398dbc;
          }
        }
      }

    }
    .table {
      margin-top: 25px;
      .el-table {
        border: 1px solid #ccc;
      }
      .el-table th{
        background: #ebf3f8;
        border: none;
        padding: 4px 0;
        font-weight: normal;
        color: #333;
      }
      .el-table td{
        border-bottom: none;
        color: #333;
        font-size: 14px;
        border-right: 1px solid #ccc;
        padding: 8px 0;
      }
    }
  }
</style>
