<template>
  <div class="hook-box">
    <el-tabs
      v-model="activeName"
      @tab-click="handleClick"
    >
      <el-tab-pane
        label="中国CFDA"
        name="first"
      >
        <h6 style="margin-top:10px; font-size:20px; color:#333;">概述</h6>
        <div class="text-box">
          中国药物标签是由中国食品和药物管理局（CFDA）批准的有关药物基因组学信息的标签。
          中国药物标签注释提供了药物，基因注释的摘要以及可下载的药物标签PDF文件。
        </div>
        <div class="table">
          <el-table
            border
            style="width: 100%"
            :data="china_CFDA_hook"
          >
            <el-table-column
              prop="drugName"
              label="药物(中文名)"
              width="180"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="drugEnglishName"
              label="药物(英文名)"
              width="180"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="geneName"
              label="基因"
              width="220"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="source"
              label="来源"
              width="220"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="literName"
              align="center"
              label="题目"
            ></el-table-column>
            <el-table-column
              prop="caozuo"
              align="center"
              label="操作"
            ></el-table-column>
          </el-table>
        </div>
      </el-tab-pane>
      <el-tab-pane
        label="全球药物标签"
        name="second"
      >
        <h6 style="margin-top:10px; font-size:20px; color:#333;">概述</h6>
        <div class="text-box">
          全球标签注释是由美国食品和药物管理局（FDA），欧洲药品管理局（EMA），瑞士医疗产品管理局（Swiss），日本医药品与医疗器械局（PMDA）和加拿大卫生部（HCSC），CFDA批准的有关药物基因组学信息的标签。
          药物标签注释提供了药物，基因注释的摘要以及可下载的药物标签PDF文件，并使用“ PGx Level”标签解释每个标签中暗含的循证等级。
          更多全球药物标签详情请查看题目。
        </div>
        <div class="table">
          <el-table
            border
            style="width: 100%"
            :data="foreign_drug_hook"
          >
            <el-table-column
              prop="drugName"
              label="药物(中文名)"
              width="180"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="drugEnglishName"
              label="药物(英文名)"
              width="180"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="geneName"
              label="基因"
              width="220"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="pgxLevel"
              label="询证等级"
              width="220"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="source"
              label="来源"
              width="220"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="literName"
              align="left"
              label="题目"
            ></el-table-column>
          </el-table>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  name: 'drug_labels_hook',
  data() {
    return {
      activeName: 'first',
      china_CFDA_hook: [],
      foreign_drug_hook: []
    }
  },
  created() {
    this.handleClick()
  },
  methods: {
    handleClick(tab, event) {
      let a = window.location.href
      let b = a.split('?')
      let c = b[1].split('&')
      let d = c[0].split('=')
      let searchKey = d[1]
      this.searchKey = decodeURI(searchKey)
      let e = c[1].split('=')
      this.id = e[1]
      let f = c[2].split('=')
      this.type = f[1]
      if (this.type === 'gene') {
        var url =
          '/apis/taskApi/getDrugLabelsByGene?id=' +
          this.id +
          '&name=' +
          this.searchKey
      } else if (this.type === 'project') {
        url = '/apis/taskApi/getDrugLabelsByDrugGene?id=' + this.id
        ;+'&name=' + this.searchKey
      } else if (this.type === 'drug') {
        url =
          '/apis/taskApi/getDrugLabelsByDrug?id=' +
          this.id +
          '&name=' +
          this.searchKey
      }
      this.loading = true
      axios({
        method: 'get',
        url: url
      })
        .then(res => {
          console.log(res.data)
          this.loading = false
          this.china_CFDA_hook = res.data.chDrugLabelDetailsList
          this.foreign_drug_hook = res.data.enDrugLabelDetailsList
        })
        .catch(err => {
          this.loading = false
        })
    }
  }
}
</script>
<style lang="scss" scoped>
.tips-list,
.left-box {
  width: 290px;
}
.text-box {
  line-height: 30px;
  color: #888;
  margin-top: 15px;
  font-size: 13px;
}
</style>
<style lang="scss">
.hook-box {
  .el-tabs__nav-scroll {
    height: 45px;
    .el-tabs__nav {
      height: 45px;
      .el-tabs__active-bar {
        background: #398dbc;
      }
      .el-tabs__item {
        font-size: 24px;
        color: #888;
        &.is-active {
          color: #398dbc;
        }
      }
    }
  }
  .table {
    margin-top: 25px;
    .el-table {
      border: 1px solid #ccc;
    }
    .el-table th {
      background: #ebf3f8;
      border: none;
      padding: 4px 0;
      font-weight: normal;
      color: #333;
    }
    .el-table td {
      border-bottom: none;
      color: #333;
      font-size: 14px;
      border-right: 1px solid #ccc;
      padding: 8px 0;
    }
  }
}
</style>
